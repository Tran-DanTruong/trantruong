import type { Metadata } from 'next'
import { Playfair_Display, Poppins } from 'next/font/google'
import './globals.css'
import Providers from '@/components/Providers'
import Header from '@/components/Header'
const serif = Playfair_Display({ subsets: ['latin', 'vietnamese'], variable: '--font-playfair' })
const sans = Poppins({ subsets: ['latin'], weight: ['300', '400', '500', '600'], variable: '--font-poppins' })
export const metadata: Metadata = { title: 'Lumière Bridal – Váy cưới cao cấp' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="vi" className={`${serif.variable} ${sans.variable}`}><body><Providers><Header /><main className="mx-auto max-w-7xl px-5">{children}</main></Providers></body></html>)
}

import Link from 'next/link'
import { getProducts } from '@/lib/api'
import ProductCard from '@/components/ProductCard'
const types = ['Công chúa', 'Đuôi cá', 'Tối giản', 'Hàn Quốc', 'Luxury', 'Phụ kiện']
export default async function Home({ searchParams }: { searchParams: Promise<{ q?: string; type?: string; max?: string }> }) {
  const sp = await searchParams
  const products = await getProducts(Object.fromEntries(Object.entries(sp).filter(([, v]) => v)) as Record<string, string>)
  return (<>
    <section className="mt-5 grid items-center gap-6 rounded-[36px] bg-gradient-to-br from-blush via-white to-sky p-8 md:grid-cols-2 md:p-12">
      <div><span className="rounded-full bg-champagne px-4 py-1 text-xs tracking-widest">✦ BỘ SƯU TẬP MÙA CƯỚI 2026</span>
        <h1 className="my-4 text-4xl leading-tight md:text-6xl">Ngày cổ tích của riêng bạn bắt đầu từ chiếc váy hoàn hảo</h1>
        <Link href="/#shop" className="btn !bg-champagne !from-champagne !to-champagne px-8 py-3.5">Khám phá bộ sưu tập ✨</Link></div>
      <div className="mx-auto grid aspect-[3/4] w-64 place-items-center rounded-t-full rounded-b-3xl bg-white/60 text-8xl shadow-soft">👰</div>
    </section>
    <section className="py-10"><h2 className="mb-5 text-3xl">Danh mục nổi bật</h2>
      <div className="grid grid-cols-3 gap-4 md:grid-cols-6">{types.map(t => (
        <Link key={t} href={`/?type=${t}#shop`} className="text-center transition hover:-translate-y-1">
          <div className="mx-auto mb-2 grid h-20 w-20 place-items-center rounded-full border-4 border-champagne bg-gradient-to-br from-blush to-sky text-3xl">👗</div>{t}</Link>))}</div></section>
    <section id="shop" className="py-6"><h2 className="mb-5 text-3xl">{sp.type ?? 'Gợi ý hôm nay'}</h2>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">{products.map(p => <ProductCard key={p.id} p={p} />)}</div>
      {!products.length && <p className="py-10 text-center">Không có sản phẩm (hãy chắc chắn API đang chạy và đã seed dữ liệu).</p>}</section>
  </>)
}

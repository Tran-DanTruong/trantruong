'use client'
import { useState } from 'react'
import { useSession, signIn } from 'next-auth/react'
import { useCart } from '@/lib/cart'
import { API, vnd } from '@/lib/api'
const PAY = [['COD', 'Thanh toán khi nhận hàng'], ['VNPay', 'VNPay'], ['Momo', 'Ví MoMo'], ['BANK', 'Chuyển khoản ngân hàng']]
export default function Cart() {
  const { items, remove, clear } = useCart(), { data: s } = useSession()
  const [pay, setPay] = useState('COD'), [addr, setAddr] = useState(''), [code, setCode] = useState(''), [msg, setMsg] = useState('')
  const sub = items.reduce((a, l) => a + l.price * l.qty, 0), off = code.toUpperCase() === 'YEU' ? Math.round(sub * .1) : code.toUpperCase() === 'CUOI' && sub ? 500000 : 0
  async function order() {
    if (!s?.user?.email) return signIn('google')
    const r = await fetch(`${API}/orders`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
      email: s.user.email, name: s.user.name, payment: pay, address: addr, coupon: code || undefined,
      items: items.map(l => ({ productId: l.id, size: l.size, color: l.color, qty: l.qty })) }) })
    if (r.ok) { clear(); setMsg('Đặt hàng thành công 💗') } else setMsg('Vui lòng nhập địa chỉ hợp lệ')
  }
  return (<div className="grid gap-5 pt-6 md:grid-cols-[1.6fr_1fr]">
    <div className="rounded-3xl border border-blush/60 p-5"><h2 className="mb-3 text-2xl">Giỏ hàng ({items.length})</h2>
      {msg && <p className="mb-3 rounded-full bg-sky px-4 py-2">{msg}</p>}
      {items.map((l, i) => <div key={i} className="flex items-center gap-3 border-t border-blush/40 py-3"><div className="grid h-16 w-12 place-items-center rounded-xl bg-gradient-to-br from-blush to-sky">👰</div>
        <div className="flex-1 text-sm"><b>{l.name}</b><br /><span className="text-ink/60">{l.color} · {l.size} · ×{l.qty}</span></div><b className="text-rose">{vnd(l.price * l.qty)}</b><button onClick={() => remove(i)}>✕</button></div>)}
      <h3 className="mb-2 mt-6 text-lg">Địa chỉ nhận hàng</h3>
      <input value={addr} onChange={e => setAddr(e.target.value)} placeholder="Số nhà, đường, quận, thành phố" className="w-full rounded-2xl border border-blush px-4 py-2.5 outline-none focus:border-rose" />
      <h3 className="mb-2 mt-5 text-lg">Phương thức thanh toán</h3>
      {PAY.map(([k, t]) => <label key={k} className={`mb-2 flex cursor-pointer gap-3 rounded-2xl border-2 px-4 py-3 ${pay === k ? 'border-rose bg-blush' : 'border-blush/60'}`}><input type="radio" checked={pay === k} onChange={() => setPay(k)} />{t}</label>)}</div>
    <div className="h-fit rounded-3xl border border-blush/60 p-5 md:sticky md:top-32"><h3 className="mb-3 text-xl">Tóm tắt đơn hàng</h3>
      <input value={code} onChange={e => setCode(e.target.value)} placeholder="Mã giảm giá: YEU, CUOI" className="mb-3 w-full rounded-full border border-blush px-4 py-2 outline-none" />
      <p className="flex justify-between"><span>Tạm tính</span>{vnd(sub)}</p><p className="flex justify-between"><span>Giảm giá</span>-{vnd(off)}</p>
      <p className="mt-2 flex justify-between border-t border-blush/40 pt-2 text-lg font-semibold text-rose"><span>Tổng</span>{vnd(sub - off)}</p>
      <button onClick={order} disabled={!items.length} className="btn mt-4 w-full disabled:opacity-50">{s ? 'Đặt hàng' : 'Đăng nhập Google để đặt hàng'}</button></div></div>)
}

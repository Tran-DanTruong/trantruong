import { notFound } from 'next/navigation'
import { getProduct, getProducts, vnd } from '@/lib/api'
import AddToCart from '@/components/AddToCart'
import ProductCard from '@/components/ProductCard'
export default async function Detail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params, p: any = await getProduct(id)
  if (!p) notFound()
  const related = (await getProducts({ type: p.type })).filter(x => x.id !== p.id).slice(0, 5)
  return (<>
    <div className="grid gap-9 pt-6 md:grid-cols-2">
      <div className="grid aspect-[3/4] place-items-center rounded-[28px] bg-gradient-to-br from-blush via-white to-sky text-9xl">👰</div>
      <div><span className="rounded-full bg-champagne px-3 py-0.5 text-xs">{p.type}</span>
        <h1 className="my-3 text-3xl">{p.name}</h1><p className="text-sm text-ink/60">★ {p.rating} · Đã bán {p.sold}</p>
        <div className="my-4 rounded-2xl bg-sky p-4 text-3xl font-semibold text-rose">{vnd(p.price)}{p.oldPrice && <s className="ml-3 text-sm font-light text-ink/50">{vnd(p.oldPrice)}</s>}</div>
        <AddToCart p={p} />
        <div className="mt-6 rounded-3xl border border-blush/60 p-5"><h3 className="mb-2 text-lg">Mô tả</h3><p className="text-sm">{p.description}</p>
          <h3 className="mb-2 mt-4 text-lg">Đánh giá ({p.reviews?.length ?? 0})</h3>
          {p.reviews?.map((r: any) => <p key={r.id} className="border-t border-blush/40 py-2 text-sm"><b>{r.user.name ?? 'Khách'}</b> {'★'.repeat(r.stars)}<br />{r.content}</p>)}</div></div></div>
    <h2 className="mb-5 mt-12 text-3xl">Sản phẩm liên quan</h2>
    <div className="grid grid-cols-2 gap-4 md:grid-cols-5">{related.map(r => <ProductCard key={r.id} p={r} />)}</div></>)
}

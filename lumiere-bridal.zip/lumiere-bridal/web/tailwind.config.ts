import type { Config } from 'tailwindcss'
export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { blush: '#FFD6E7', sky: '#DDEEFF', champagne: '#F5E6C8', ink: '#4a3b47', rose: '#d6688f' },
    fontFamily: { serif: ['var(--font-playfair)', 'serif'], sans: ['var(--font-poppins)', 'sans-serif'] },
    boxShadow: { soft: '0 18px 40px rgba(214,104,143,.18)' } } },
} satisfies Config

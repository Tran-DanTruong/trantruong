export type Product = { id: number; name: string; type: string; price: number; oldPrice: number | null; tag: string | null; rating: number; sold: number; description: string }
export const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api'
export const vnd = (n: number) => n.toLocaleString('vi-VN') + '₫'
export async function getProducts(p: Record<string, string> = {}): Promise<Product[]> {
  const r = await fetch(`${API}/products?` + new URLSearchParams(p), { cache: 'no-store' }); return r.ok ? r.json() : []
}
export async function getProduct(id: string): Promise<Product | null> {
  const r = await fetch(`${API}/products/${id}`, { cache: 'no-store' }); return r.ok ? r.json() : null
}

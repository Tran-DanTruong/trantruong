'use client'
import { createContext, useContext, useEffect, useState } from 'react'
export type Line = { id: number; name: string; price: number; size: string; color: string; qty: number }
const Ctx = createContext<{ items: Line[]; add: (l: Line) => void; remove: (i: number) => void; clear: () => void }>(null!)
export const useCart = () => useContext(Ctx)
export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Line[]>([])
  useEffect(() => { setItems(JSON.parse(localStorage.getItem('cart') ?? '[]')) }, [])
  useEffect(() => { localStorage.setItem('cart', JSON.stringify(items)) }, [items])
  return <Ctx.Provider value={{ items, add: l => setItems(x => [...x, l]), remove: i => setItems(x => x.filter((_, k) => k !== i)), clear: () => setItems([]) }}>{children}</Ctx.Provider>
}

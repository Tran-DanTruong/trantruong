'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useCart } from '@/lib/cart'
import { Product } from '@/lib/api'
const COLORS = ['Trắng ngọc trai', 'Hồng phấn', 'Xanh sương']
export default function AddToCart({ p }: { p: Product }) {
  const [size, setSize] = useState('M'), [color, setColor] = useState(COLORS[0]), [qty, setQty] = useState(1)
  const { add } = useCart(), router = useRouter()
  const go = (buy?: boolean) => { add({ id: p.id, name: p.name, price: p.price, size, color, qty }); if (buy) router.push('/cart') }
  const opt = (on: boolean) => `rounded-full border-2 px-4 py-1.5 transition ${on ? 'border-rose bg-blush' : 'border-blush/60'}`
  return (<div className="space-y-4">
    <div><p className="mb-1 text-sm text-ink/60">Kích thước</p><div className="flex gap-2">{['S', 'M', 'L', 'XL'].map(s => <button key={s} onClick={() => setSize(s)} className={opt(s === size)}>{s}</button>)}</div></div>
    <div><p className="mb-1 text-sm text-ink/60">Màu sắc</p><div className="flex flex-wrap gap-2">{COLORS.map(c => <button key={c} onClick={() => setColor(c)} className={opt(c === color)}>{c}</button>)}</div></div>
    <div className="flex w-fit items-center rounded-full border border-blush"><button className="h-9 w-9" onClick={() => setQty(Math.max(1, qty - 1))}>−</button><span className="w-8 text-center">{qty}</span><button className="h-9 w-9" onClick={() => setQty(qty + 1)}>+</button></div>
    <div className="flex gap-3"><button onClick={() => go()} className="btn-o flex-1">Thêm vào giỏ</button><button onClick={() => go(true)} className="btn flex-1">Mua ngay</button></div></div>)
}

'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { signIn, signOut, useSession } from 'next-auth/react'
import { Heart, Search, ShoppingBag, User } from 'lucide-react'
import { useCart } from '@/lib/cart'
const nav = [['Trang chủ', '/'], ['Váy cưới', '/#shop'], ['Váy dạ hội', '/?type=Luxury#shop'], ['Phụ kiện cưới', '/?type=Phụ kiện#shop'], ['Bộ sưu tập mới', '/#shop'], ['Blog', '#']]
export default function Header() {
  const { data: s } = useSession(), { items } = useCart(), router = useRouter()
  return (
    <header className="sticky top-0 z-20 border-b border-blush/60 bg-white/85 backdrop-blur">
      <div className="mx-auto max-w-7xl px-5">
        <div className="flex flex-wrap items-center gap-4 py-3">
          <Link href="/" className="mr-auto flex items-center gap-2 font-serif text-2xl font-bold">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-blush to-sky text-rose"><Heart size={18} /></span>Lumière Bridal</Link>
          <form onSubmit={e => { e.preventDefault(); router.push('/?q=' + new FormData(e.currentTarget).get('q') + '#shop') }}
            className="order-last flex w-full flex-1 items-center gap-2 rounded-full border-2 border-blush py-1 pl-4 pr-1 focus-within:ring-4 focus-within:ring-blush md:order-none md:w-auto">
            <Search size={18} /><input name="q" placeholder="Tìm váy công chúa, đuôi cá, phụ kiện…" className="min-w-0 flex-1 bg-transparent py-2 outline-none" /><button className="btn !py-2">Tìm</button></form>
          <button onClick={() => (s ? signOut() : signIn('google'))} title={s ? 'Đăng xuất' : 'Đăng nhập với Google'} className="grid h-10 w-10 place-items-center rounded-full border border-blush hover:bg-blush">
            {s?.user?.image ? <img src={s.user.image} alt="" className="h-8 w-8 rounded-full" /> : <User size={18} />}</button>
          <Link href="/#shop" className="grid h-10 w-10 place-items-center rounded-full border border-blush hover:bg-blush"><Heart size={18} /></Link>
          <Link href="/cart" className="relative grid h-10 w-10 place-items-center rounded-full border border-blush hover:bg-blush"><ShoppingBag size={18} />
            {items.length > 0 && <b className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-rose text-[10px] text-white">{items.length}</b>}</Link>
        </div>
        <nav className="flex gap-1 overflow-x-auto pb-2">{nav.map(([t, h]) => <Link key={t} href={h} className="whitespace-nowrap rounded-full px-4 py-1.5 text-sm text-ink/70 transition hover:bg-sky hover:text-ink">{t}</Link>)}</nav>
      </div>
    </header>)
}

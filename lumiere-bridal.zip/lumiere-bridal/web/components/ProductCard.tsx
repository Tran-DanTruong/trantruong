'use client'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Heart } from 'lucide-react'
import { Product, vnd } from '@/lib/api'
export default function ProductCard({ p }: { p: Product }) {
  return (
    <motion.div whileHover={{ y: -6 }} transition={{ type: 'spring', stiffness: 300 }} className="overflow-hidden rounded-[24px] border border-blush/60 bg-white hover:shadow-soft">
      <Link href={`/products/${p.id}`}>
        {/* TODO: thay bằng <Image src={p.image}/> khi có ảnh thật */}
        <div className="relative grid aspect-[3/4] place-items-center bg-gradient-to-br from-blush via-white to-sky text-6xl">👰
          {p.tag && <span className="absolute left-3 top-3 rounded-full bg-champagne px-3 py-0.5 text-[11px] font-semibold">{p.tag}</span>}
          <span className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/80"><Heart size={16} /></span></div>
        <div className="p-3.5"><h3 className="min-h-10 font-sans text-sm font-medium leading-snug">{p.name}</h3>
          <div className="font-semibold text-rose">{vnd(p.price)}{p.oldPrice && <s className="ml-2 text-xs font-light text-ink/50">{vnd(p.oldPrice)}</s>}</div>
          <div className="mt-1 flex justify-between text-xs text-ink/50"><span>★ {p.rating}</span><span>Đã bán {p.sold}</span></div></div>
      </Link>
    </motion.div>)
}

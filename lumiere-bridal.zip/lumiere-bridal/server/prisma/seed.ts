import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
const d = (name:string,type:string,price:number,oldPrice:number|null,tag:string|null,rating:number,sold:number)=>({name,type,price,oldPrice,tag,rating,sold,description:'Thiết kế lấy cảm hứng cổ tích châu Âu, ren Pháp và tulle cao cấp, đính tay ngọc trai.'})
async function main(){
  await db.product.deleteMany()
  await db.product.createMany({data:[
    d('Váy công chúa Aurora ren tầng','Công chúa',18900000,24900000,'Best Seller',4.9,1280),
    d('Váy đuôi cá Seraphina','Đuôi cá',15500000,null,'New',4.8,860),
    d('Váy tối giản Élise satin','Tối giản',12800000,null,null,4.7,640),
    d('Váy cưới Hàn Quốc Hana','Hàn Quốc',9900000,13900000,'Sale',4.8,2100),
    d('Váy Luxury Versailles đính pha lê','Luxury',38000000,null,'Best Seller',5,310),
    d('Váy công chúa Cinderella tulle','Công chúa',16700000,19900000,'Sale',4.9,950),
    d('Váy đuôi cá Isabelle ren Pháp','Đuôi cá',17900000,null,'New',4.6,420),
    d('Váy tối giản Camille cổ vuông','Tối giản',11200000,14500000,'Sale',4.7,730),
    d('Váy Hàn Quốc Soo-ah nơ bồng','Hàn Quốc',10800000,null,'New',4.8,1560),
    d('Váy Luxury Marie Antoinette','Luxury',46000000,null,null,4.9,180),
    d('Vương miện pha lê Tiara','Phụ kiện',2400000,3200000,'Sale',4.9,3200),
    d('Voan cưới ren dài 3m','Phụ kiện',1900000,null,'Best Seller',4.8,2780)]})
  await db.coupon.createMany({data:[{code:'YEU',percent:10},{code:'CUOI',amount:500000}],skipDuplicates:true})
}
main().finally(()=>db.$disconnect())

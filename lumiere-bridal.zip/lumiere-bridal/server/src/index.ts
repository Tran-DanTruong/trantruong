import express from 'express'
import cors from 'cors'
import { z } from 'zod'
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
const app = express()
app.use(cors({ origin: process.env.WEB_URL ?? 'http://localhost:3000' }), express.json())
const user = (email: string, name?: string) => db.user.upsert({ where: { email }, update: {}, create: { email, name } })

app.get('/api/products', async (req, res) => {
  const { q, type, max } = req.query as Record<string, string>
  res.json(await db.product.findMany({
    where: { ...(q && { name: { contains: q, mode: 'insensitive' } }), ...(type && { type }), ...(max && { price: { lte: +max } }) },
    orderBy: { sold: 'desc' } }))
})
app.get('/api/products/:id', async (req, res) => {
  const p = await db.product.findUnique({ where: { id: +req.params.id }, include: { reviews: { include: { user: { select: { name: true } } } } } })
  p ? res.json(p) : res.status(404).json({ error: 'Not found' })
})
const orderBody = z.object({ email: z.string().email(), name: z.string().optional(), payment: z.enum(['COD', 'VNPay', 'Momo', 'BANK']),
  address: z.string().min(5), coupon: z.string().optional(),
  items: z.array(z.object({ productId: z.number(), size: z.string(), color: z.string(), qty: z.number().min(1) })).min(1) })
app.post('/api/orders', async (req, res) => {
  const b = orderBody.safeParse(req.body)
  if (!b.success) return res.status(400).json(b.error.flatten())
  const { email, name, payment, address, items, coupon } = b.data
  const prods = await db.product.findMany({ where: { id: { in: items.map(i => i.productId) } } })
  const lines = items.map(i => ({ ...i, price: prods.find(p => p.id === i.productId)?.price ?? 0 }))
  let total = lines.reduce((a, l) => a + l.price * l.qty, 0)
  const c = coupon && await db.coupon.findUnique({ where: { code: coupon.toUpperCase() } })
  if (c) total -= c.percent ? Math.round(total * c.percent / 100) : c.amount
  const u = await user(email, name)
  res.json(await db.order.create({ data: { userId: u.id, total: Math.max(0, total), payment, address, items: { create: lines } }, include: { items: true } }))
})
app.get('/api/orders', async (req, res) =>
  res.json(await db.order.findMany({ where: { user: { email: String(req.query.email) } }, include: { items: { include: { product: true } } }, orderBy: { createdAt: 'desc' } })))
app.post('/api/wishlist', async (req, res) => {
  const u = await user(req.body.email); const k = { userId_productId: { userId: u.id, productId: +req.body.productId } }
  const has = await db.wishlist.findUnique({ where: k })
  has ? await db.wishlist.delete({ where: k }) : await db.wishlist.create({ data: { userId: u.id, productId: +req.body.productId } })
  res.json({ liked: !has })
})
app.post('/api/reviews', async (req, res) => {
  const u = await user(req.body.email, req.body.name)
  res.json(await db.review.create({ data: { productId: +req.body.productId, userId: u.id, stars: Math.min(5, Math.max(1, +req.body.stars)), content: req.body.content } }))
})
app.get('/api/admin/stats', async (req, res) => {
  if (req.header('x-admin-key') !== process.env.ADMIN_KEY) return res.status(401).json({ error: 'Unauthorized' })
  const [revenue, orders, customers] = await Promise.all([db.order.aggregate({ _sum: { total: true } }), db.order.count(), db.user.count()])
  res.json({ revenue: revenue._sum.total ?? 0, orders, customers })
})
app.listen(4000, () => console.log('API http://localhost:4000'))

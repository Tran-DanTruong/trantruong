# Lumière Bridal – Next.js 15 + Express + Prisma + PostgreSQL

## Chạy
1. Tạo database PostgreSQL (vd: `createdb lumiere`).
2. **Backend**: `cd server && cp .env.example .env && npm i && npx prisma migrate dev --name init && npm run seed && npm run dev` (http://localhost:4000)
3. **Frontend**: `cd web && cp .env.example .env.local && npm i && npm run dev` (http://localhost:3000)
4. Đăng nhập Google thật: tạo OAuth Client ID tại console.cloud.google.com, redirect URI `http://localhost:3000/api/auth/callback/google`, điền vào `web/.env.local`.

## Đã có
Trang chủ (hero, danh mục, lọc, tìm kiếm), chi tiết sản phẩm (size/màu/số lượng), giỏ hàng + thanh toán (COD/VNPay/Momo/chuyển khoản, mã YEU/CUOI), đăng nhập Google (NextAuth), API sản phẩm/đơn hàng/wishlist/đánh giá/thống kê admin.
## Chưa có (làm tiếp)
Trang tài khoản, Admin UI, chat/AI tư vấn, push notification, shadcn/ui (`npx shadcn@latest init`), ảnh sản phẩm thật (thay placeholder trong ProductCard).
